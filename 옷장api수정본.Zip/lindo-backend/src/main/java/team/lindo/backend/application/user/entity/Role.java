package team.lindo.backend.application.user.entity;

public enum Role {
    USER, ADMIN;
}
