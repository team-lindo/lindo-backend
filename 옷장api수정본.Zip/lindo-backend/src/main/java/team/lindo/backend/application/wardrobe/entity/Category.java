package team.lindo.backend.application.entity;

public enum Category {
    OUTER, TOP, BOTTOM, SHOES, ACCESSORY
}
