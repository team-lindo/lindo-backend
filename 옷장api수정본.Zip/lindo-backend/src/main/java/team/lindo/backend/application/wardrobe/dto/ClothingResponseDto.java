package team.lindo.backend.application.dto;

import team.lindo.backend.application.entity.*;
import lombok.Getter;

@Getter
public class ClothingResponseDto {
    private Long id;
    private String name;
    private String imageUrl;
    private Double price;
    private Category category;

    public ClothingResponseDto(Clothing clothing) {
        this.id = clothing.getId();
        this.name = clothing.getName();
        this.imageUrl = clothing.getImageUrl();
        this.price = clothing.getPrice();
        this.category = clothing.getCategory();
    }
}
