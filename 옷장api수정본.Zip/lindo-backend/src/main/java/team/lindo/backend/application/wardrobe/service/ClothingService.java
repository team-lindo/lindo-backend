package team.lindo.backend.application.business.service;

import jakarta.persistence.EntityNotFoundException;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import team.lindo.backend.application.entity.Category;
import team.lindo.backend.application.repository.ClothingRepository;
import team.lindo.backend.application.entity.Clothing;
import team.lindo.backend.application.dto.ClothingResponseDto;
import java.util.List;
import java.util.Optional;


@Service
@RequiredArgsConstructor
public class ClothingService {

    private final ClothingRepository clothingRepository;

    // 옷 저장 기능
    public Clothing addClothing(Clothing clothing) {
        return clothingRepository.save(clothing);
    }

    // 모든 옷 조회 기능
    public List<Clothing> getAllClothes() {
        return clothingRepository.findAll();
    }

    //삭제되지 않은 옷 조회 기능
    public List<Clothing> getAllActiveClothing() {
        return clothingRepository.findByIsDeletedFalse();
    }

    // 카테고리별 옷 조회 기능
    public List<Clothing> getClothesByCategory(Category category) {
        return clothingRepository.findByCategory(category);
    }

    // id로 옷 조회
    public Optional<Clothing> getClothingById(Long id) {
        return clothingRepository.findById(id);
    }

    // 옷 정보 수정
    public ClothingResponseDto  updateClothing(Long id, Clothing clothingDetails) {
        Clothing clothing = clothingRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("옷을 찾을 수 없습니다."));

        clothing.setName(clothingDetails.getName());
        clothing.setImageUrl(clothingDetails.getImageUrl());
        clothing.setPrice(clothingDetails.getPrice());
        clothing.setCategory(clothingDetails.getCategory());

        Clothing updatedClothing = clothingRepository.save(clothing);
        return new ClothingResponseDto(updatedClothing);
    }

    // 옷 삭제
    public void deleteClothing(Long id) {
        Clothing clothing = clothingRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("옷을 찾을 수 없습니다."));

        clothing.setDeleted(true); // 소프트 딜리트
        clothingRepository.save(clothing);
    }

    // 삭제 된 옷 복구
//    public void restoreClothing(Long id) {
//        Clothing clothing = clothingRepository.findById(id)
//                .orElseThrow(() -> new EntityNotFoundException("Clothing not found"));
//
//        clothing.setDeleted(false);
//        clothingRepository.save(clothing);
//    }
}
