package team.lindo.backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LindoBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
