package team.lindo.backend.application.wardrobe.dto;

import lombok.Getter;

@Getter
public class WardrobeItemDto {
    private Long productId;
    private String category;
    private String productName;
    private double price;

    // 모든 필드를 초기화하는 생성자
    public WardrobeItemDto(Long productId, String category, String productName, double price) {
        this.productId = productId;
        this.category = category;
        this.productName = productName;
        this.price = price;
    }
}
