package team.lindo.backend.presentation.controller.app;


import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import team.lindo.backend.application.wardrobe.dto.WardrobeItemDto;
import team.lindo.backend.application.wardrobe.entity.Wardrobe;
import team.lindo.backend.application.wardrobe.service.WardrobeService;
import team.lindo.backend.presentation.common.response.ResponseGenerator;

@RestController
@RequestMapping("/wardrobe")
@RequiredArgsConstructor
public class WardrobeController {

    private WardrobeService wardrobeService;

    @GetMapping("/{userId}")
    public ResponseEntity<?> getWardrobe(@PathVariable Long userId) {
        Wardrobe wardrobe = wardrobeService.getWardrobeByUserId(userId);
        return ResponseEntity.ok(wardrobe);
    }

    @GetMapping("/{userId}/items")
    public ResponseEntity<?> getWardrobeItems(@PathVariable Long userId) {
        return ResponseEntity.ok(ResponseGenerator.getMultipleDataResponse(wardrobeService.getItemsByUser(userId)));
    }

    @PostMapping("/{userId}/items")
    public ResponseEntity<?> addItem(@PathVariable Long userId, @RequestBody WardrobeItemDto dto) {
        return ResponseEntity.ok(ResponseGenerator.getSingleDataResponse(wardrobeService.addItemToWardrobe(userId, dto)));
    }

    @DeleteMapping("/items/{itemId}")
    public ResponseEntity<?> deleteItem(@PathVariable Long itemId) {
        wardrobeService.deleteItem(itemId);
        return ResponseEntity.ok(ResponseGenerator.getSuccessResponse());
    }
}
