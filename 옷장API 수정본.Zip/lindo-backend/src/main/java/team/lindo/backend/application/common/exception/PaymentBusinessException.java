package team.lindo.backend.application.common.exception;

public class PaymentBusinessException extends BusinessException {
    public PaymentBusinessException(String message) {
        super(message);
    }
}
