package team.lindo.backend.application.wardrobe.repository;


import org.springframework.data.jpa.repository.JpaRepository;
import team.lindo.backend.application.wardrobe.entity.WardrobeItem;

import java.util.List;

public interface WardrobeItemRepository extends JpaRepository<WardrobeItem, Long> {
    List<WardrobeItem> findByWardrobeUserId(Long userId);
}
