package team.lindo.backend.application.wardrobe.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Clothing {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String imageUrl;
    private double price;

    @Enumerated(EnumType.STRING)
    private Category category;

    private boolean isDeleted = false; // 삭제 여부 플래그 (소프트 딜리트)
}
