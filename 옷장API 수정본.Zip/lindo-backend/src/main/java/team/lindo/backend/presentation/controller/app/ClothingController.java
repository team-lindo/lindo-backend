package team.lindo.backend.presentation.controller.app;

import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import team.lindo.backend.application.wardrobe.service.ClothingService;
import team.lindo.backend.application.wardrobe.dto.ClothingResponseDto;
import team.lindo.backend.application.wardrobe.entity.*;
import team.lindo.backend.presentation.common.response.ResponseGenerator;
import team.lindo.backend.presentation.common.response.payload.SuccessResponse;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/clothes")
@RequiredArgsConstructor
public class ClothingController {

    private final ClothingService clothingService;

    // 옷 등록 api
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<SuccessResponse.Single<ClothingResponseDto>> addClothing(@RequestBody Clothing clothing) {
        ClothingResponseDto responseDto = new ClothingResponseDto(clothingService.addClothing(clothing));
        return ResponseEntity.ok(ResponseGenerator.getSingleDataResponse(responseDto));
    }

    // 모든 옷 조회 api
    @GetMapping
    public ResponseEntity<SuccessResponse.Multiple<ClothingResponseDto>> getAllClothes() {
        List<ClothingResponseDto> clothes = clothingService.getAllClothes().stream()
                .map(ClothingResponseDto::new)
                .toList();
        return ResponseEntity.ok(ResponseGenerator.getMultipleDataResponse(clothes));
    }

    // 삭제되지 않은 옷 조회 api
    @GetMapping("/active")
    public ResponseEntity<SuccessResponse.Multiple<ClothingResponseDto>> getActiveClothing() {
        List<ClothingResponseDto> activeClothes = clothingService.getAllActiveClothing().stream()
                .map(ClothingResponseDto::new)
                .toList();
        return ResponseEntity.ok(ResponseGenerator.getMultipleDataResponse(activeClothes));
    }

    //id로 옷 조회 api
    @GetMapping("/{id}")
    public ResponseEntity<SuccessResponse.Single<ClothingResponseDto>> getClothingById(@PathVariable Long id) {
        Clothing clothing = clothingService.getClothingById(id)
                .orElseThrow(() -> new RuntimeException ("옷을 찾을 수 없습니다."));
        return ResponseEntity.ok(ResponseGenerator.getSingleDataResponse(new ClothingResponseDto(clothing)));
    }

    // 카테고리별 옷 조회 api
    @GetMapping("/category/{category}")
    public ResponseEntity<SuccessResponse.Multiple<ClothingResponseDto>> getClothesByCategory(@PathVariable Category category) {
        List<ClothingResponseDto> clothesByCategory = clothingService.getClothesByCategory(category).stream()
                .map(ClothingResponseDto::new)
                .toList();
        return ResponseEntity.ok(ResponseGenerator.getMultipleDataResponse(clothesByCategory));
    }

    // 옷 수정 api
    @PutMapping("/{id}")
    public ResponseEntity<SuccessResponse.Single<ClothingResponseDto>> updateClothing(@PathVariable Long id, @RequestBody Clothing clothing) {
        ClothingResponseDto updatedClothing = clothingService.updateClothing(id, clothing);
        return ResponseEntity.ok(ResponseGenerator.getSingleDataResponse(updatedClothing));
    }

    // 옷 삭제 api
    @DeleteMapping("/{id}")
    public ResponseEntity<SuccessResponse.Single<String>> deleteClothing(@PathVariable Long id) {
        clothingService.deleteClothing(id);
        return ResponseEntity.ok(ResponseGenerator.getSingleDataResponse("삭제"));
    }
}
