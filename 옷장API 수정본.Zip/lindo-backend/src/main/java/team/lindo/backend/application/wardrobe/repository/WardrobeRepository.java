package team.lindo.backend.application.wardrobe.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import team.lindo.backend.application.wardrobe.entity.Wardrobe;

public interface WardrobeRepository extends JpaRepository<Wardrobe, Long> {
    Wardrobe findByUserId(Long userId);
}
