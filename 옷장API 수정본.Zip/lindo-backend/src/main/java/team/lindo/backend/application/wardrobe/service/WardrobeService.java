package team.lindo.backend.application.wardrobe.service;

import team.lindo.backend.application.product.entity.Product;
import team.lindo.backend.application.wardrobe.dto.WardrobeItemDto;
import team.lindo.backend.application.wardrobe.entity.Wardrobe;
import team.lindo.backend.application.wardrobe.entity.WardrobeItem;
import team.lindo.backend.application.wardrobe.repository.WardrobeRepository;
import team.lindo.backend.application.wardrobe.repository.WardrobeItemRepository;
import team.lindo.backend.application.product.repository.ProductRepository;
import team.lindo.backend.application.product.repository.CategoryRepository;

import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class WardrobeService {

    private WardrobeRepository wardrobeRepository;

    private WardrobeItemRepository wardrobeItemRepository;

    private ProductRepository productRepository;

    private CategoryRepository categoryRepository;

    public List<WardrobeItem> getItemsByUser(Long userId) {
        return wardrobeItemRepository.findByWardrobeUserId(userId);
    }

    public WardrobeItem addItemToWardrobe(Long userId, WardrobeItemDto dto) {
        Wardrobe wardrobe = wardrobeRepository.findByUserId(userId);

        Product product = productRepository.findById(dto.getProductId())
                .orElseThrow(() -> new RuntimeException("Product not found"));

        Category category = categoryRepository.findById(dto.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found"));

        WardrobeItem item = new WardrobeItem();
        item.setWardrobe(wardrobe);
        item.setProduct(product);
        item.setCategory(category);

        return wardrobeItemRepository.save(item);
    }

    public void deleteItem(Long itemId) {
        wardrobeItemRepository.deleteById(itemId);
    }
}
