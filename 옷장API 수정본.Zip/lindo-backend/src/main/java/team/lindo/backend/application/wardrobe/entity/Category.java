package team.lindo.backend.application.wardrobe.entity;

public enum Category {
    OUTER, TOP, BOTTOM, SHOES, ACCESSORY
}
